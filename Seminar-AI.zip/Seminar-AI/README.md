# Vietnamese Sentiment Classification — PhoBERT Fine‑Tuning

This project provides a **beginner‑friendly training pipeline** for fine‑tuning **PhoBERT** on a Vietnamese sentiment dataset. The training workflow uses **Hugging Face Transformers**, **PyTorch**, and **MLflow** for experiment tracking.

## Overview

-   Fine-tune PhoBERT on custom CSV datasets
-   Track experiments with MLflow
-   Evaluate accuracy, precision, recall, F1
-   Save and load trained models
-   Build server for API 
-   Build website use model
-   Test model in teminal
-   Test model in website

# 1. Setup Virtual Environment

It is recommended to use a virtual environment to manage dependencies.

```bash
# Create virtual environment
python -m venv venv

# Activate (Windows)
venv\Scripts\activate

# Activate (Linux / macOS)
source venv/bin/activate

## Run Training

``` bash
python train.py  --train_csv "vi_sentiment_10k_train.csv" --val_csv "vi_sentiment_10k_val.csv" --test_csv "vi_sentiment_10k_test.csv" --output_dir "./phobert_finetuned" --base_model "vinai/phobert-base" --epochs 3 --batch_size 16 --mlflow_uri "file:./mlruns" --mlflow_run_name "phobert_finetune_10k" --eval_every_epoch --load_best
```

## Main Arguments

  | Argument           |   Description                  |
  --------------------- -------------------------------
  | `--train_csv`	     |   Path to training CSV file (required) |
  | `--val_csv`	       |   Path to validation CSV file (optional) |
  | `--test_csv`	     |   Path to test CSV file (optional) |
  | `--output_dir`	   |   Directory to save model checkpoints & final model |
  | `--base_model`	   |   Pretrained model name (default: vinai/phobert-base) |
  | `--epochs`	       |   Number of training epochs |
  | `--batch_size`	   |   Batch size for both training & eval |
  | `--max_length`	   |   Max token length for tokenizer |
  | `--mlflow_uri`	   |   MLflow logging storage (default: file:./mlruns) |
  | `--mlflow_run_name`|	  Name of the MLflow experiment run |
  | `--push_to_hub`	   |   HuggingFace Hub repo name (username/repo) if you want to upload model |
  | `--eval_every_epoch` |	Enable evaluation at the end of each epoch |
  | `--load_best`	     |   Load the best checkpoint based on validation metric |
  | `--no_cuda`	       |   Force training on CPU |
  | `--fp16`	         |   Enable mixed-precision training (faster on GPUs) |


## Evaluation

The script prints: - Accuracy\
- Precision / Recall / F1\
- Confusion matrix\
- Classification report

All metrics are also logged to MLflow.

## Output

After training, the output directory contains: - model weights\
- tokenizer\
- training logs\
- MLflow metrics
